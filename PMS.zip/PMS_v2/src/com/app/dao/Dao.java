package com.app.dao;

public interface Dao {

}
