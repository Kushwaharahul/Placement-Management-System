
DROP TABLE IF EXISTS paper;

create table paper(
s_no int(11) primary key auto_increment,
question varchar(1000) NOT NULL,
correct_choice varchar(1) NOT NULL
);


insert into paper values(1,'ENORMOUS, then which of the Antonyms?','B');
insert into paper values(2,'COMMISSIONED, then which of the Antonyms?','C');
insert into paper values(3,'ARTIFICIAL, then which of the Antonyms?','D');
insert into paper values(4,'ARTIFICIAL, then which of the Antonyms?','E');
insert into paper values(5,'ARTIFICIAL, then which of the Antonyms?','Natural');

insert into paper values(6,'ARTIFICIAL, then which of the Antonyms?','Natural');

insert into paper values(7,'ARTIFICIAL, then which of the Antonyms?','Natural');

insert into paper values(8,'ARTIFICIAL, then which of the Antonyms?','Natural');
insert into paper values(9,'ARTIFICIAL, then which of the Antonyms?','Natural');
insert into paper values(10,'ARTIFICIAL, then which of the Antonyms?','Natural');



